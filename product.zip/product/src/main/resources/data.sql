insert into product(product_id,product_name,catagory,price)  
values(1,'Tomato','vegetables',20);  
insert into product(product_id,product_name,catagory,price)  
values(2,'Apple','Fruits',40);  
insert into cart(product_id,product_name,catagory,price)  
values(2,'Apple','Fruits',40);  