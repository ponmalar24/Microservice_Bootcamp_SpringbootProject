package com.tth.common.exceptions;

public class IdNotFoundException extends RuntimeException {

}
